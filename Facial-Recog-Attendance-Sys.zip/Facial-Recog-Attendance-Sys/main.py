from unittest import result
import cv2
import numpy as np
import cmake
import dlib
import face_recognition

imgOcman = face_recognition.load_image_file('imagesBasic/ocman.jpg')
imgOcman = cv2.cvtColor(imgOcman,cv2.COLOR_BGR2RGB)
faceLoc = face_recognition.face_locations(imgOcman)[0]
encodeOcman = face_recognition.face_encodings(imgOcman)[0]
cv2.rectangle(imgOcman,(faceLoc[3],faceLoc[0]),(faceLoc[1],faceLoc[2]),(0,255,0),2)

imgUsman = face_recognition.load_image_file('imagesBasic/Usman.jpg')
imgUsman = cv2.cvtColor(imgUsman,cv2.COLOR_BGR2RGB)
faceLoc2 = face_recognition.face_locations(imgUsman)[0]
encodeUsman = face_recognition.face_encodings(imgUsman)[0]
cv2.rectangle(imgUsman,(faceLoc2[3],faceLoc2[0]),(faceLoc2[1],faceLoc2[2]),(0,255,0),2)


results = face_recognition.compare_faces([encodeOcman],encodeUsman)
faceDis = face_recognition.face_distance([encodeOcman],encodeUsman)
print(results,faceDis)
cv2.putText(imgOcman,f'{results}{round(faceDis[0],2)}',(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255),2)

cv2.imshow('Ocman', imgOcman)
cv2.imshow('Usman', imgUsman)

cv2.waitKey(0)